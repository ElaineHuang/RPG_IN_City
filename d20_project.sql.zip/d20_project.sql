-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主機: localhost
-- 建立日期: Jan 05, 2015, 09:02 AM
-- 伺服器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 資料庫: `d20_project`
-- 

-- --------------------------------------------------------

-- 
-- 資料表格式： `board`
-- 

CREATE TABLE `board` (
  `gid` int(11) NOT NULL auto_increment,
  `name` varchar(20) collate utf8_unicode_ci NOT NULL,
  `title` varchar(60) collate utf8_unicode_ci NOT NULL,
  `content` varchar(200) collate utf8_unicode_ci NOT NULL,
  `style` varchar(20) collate utf8_unicode_ci NOT NULL,
  `time` date NOT NULL,
  PRIMARY KEY  (`gid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

-- 
-- 列出以下資料庫的數據： `board`
-- 

INSERT INTO `board` VALUES (12, 'Amy', '面紙不夠用', '如提，可以拿多一點面紙在房間嗎?備感困擾', 'S', '2014-12-27');
INSERT INTO `board` VALUES (25, 'Amy', '崩潰中...', '子留言不能刪是哪招啦!!\r\n', 'Q', '2015-01-01');
INSERT INTO `board` VALUES (26, 'Amy', '沒衛生紙', '房號502沒有衛生紙啦~~求救~~', 'Q', '2015-01-01');
INSERT INTO `board` VALUES (27, 'Elaine', '這附近有租機車的地方嗎', '如提', 'Q', '2015-01-01');
INSERT INTO `board` VALUES (31, 'Elaine', '這附近哪裡有加油站啊', '如提~~', 'Q', '2015-01-01');
INSERT INTO `board` VALUES (32, 'Chad', '今天抽獎', '今天抽到折價卷~可以半價住一天ㄟ\r\n超開勳der', 'M', '2015-01-01');
INSERT INTO `board` VALUES (33, 'Amy', '今天抽獎', '今天抽到可以半價住一天耶  超開勳der~', 'M', '2015-01-01');

-- --------------------------------------------------------

-- 
-- 資料表格式： `member`
-- 

CREATE TABLE `member` (
  `account` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `name` varchar(15) character set utf8 collate utf8_unicode_ci NOT NULL,
  `birth` date NOT NULL,
  `phone` varchar(25) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(35) character set utf8 collate utf8_unicode_ci NOT NULL,
  `picture` varchar(40) character set utf8 collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 列出以下資料庫的數據： `member`
-- 

INSERT INTO `member` VALUES ('aaa', 'bbb', 'LINE', '2014-12-16', '09888888', 'amy87ddd@yahoo.com', 'cat.jpg');
INSERT INTO `member` VALUES ('bbb', 'bbb', 'bbb', '2014-12-08', '00000000', 'lulu87@yahoo.com', NULL);
INSERT INTO `member` VALUES ('ccccc', 'ccccc', 'ccc', '2014-12-31', '00000000', 'sss@sss', NULL);
INSERT INTO `member` VALUES ('pigpig', 'ppiigg', '連勝文', '2014-12-16', '09852432122', 'Pig@yahoo.com', 'lianpig.jpg');
INSERT INTO `member` VALUES ('admin', 'php', '管理員', '2014-12-02', '09852146525ww', 'admin@yahoo.com.tw', 'Penguins.jpg');
INSERT INTO `member` VALUES ('professor', 'professorp', '柯文哲', '2014-11-06', '0985422222', 'professor@gmail.com', 'professor.jpg');
INSERT INTO `member` VALUES ('queen', 'queen', '奇承娘', '2014-11-06', '08524225', 'queen@yahoo.com', NULL);
INSERT INTO `member` VALUES ('mis101bird', 'abcd', '軒如', '2013-01-01', '0922369033', 'mis101bird@gmail.com', NULL);

-- --------------------------------------------------------

-- 
-- 資料表格式： `suboard`
-- 

CREATE TABLE `suboard` (
  `gid` int(11) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(60) collate utf8_unicode_ci NOT NULL,
  `content` varchar(200) collate utf8_unicode_ci NOT NULL,
  `time` date NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=59 ;

-- 
-- 列出以下資料庫的數據： `suboard`
-- 

INSERT INTO `suboard` VALUES (12, 7, 'admin', '好的~馬上處理~', '2014-12-27');
INSERT INTO `suboard` VALUES (26, 28, 'admin', '好ㄉ~我們馬上處理喔', '2015-01-01');
INSERT INTO `suboard` VALUES (27, 29, 'Elaine', '有喔  在附近', '2015-01-01');
INSERT INTO `suboard` VALUES (27, 30, 'Amy', '在大潤發旁邊', '2015-01-01');
INSERT INTO `suboard` VALUES (31, 44, 'Amy', '7-11對面有家中油喔~~可以去看看', '2015-01-01');
INSERT INTO `suboard` VALUES (12, 46, 'Chad', '我也需要\n', '2015-01-01');
INSERT INTO `suboard` VALUES (31, 49, 'Elaine', '謝謝你喔~~', '2015-01-01');
INSERT INTO `suboard` VALUES (31, 50, 'Elaine', 'ㄜ  請問哪裡有7-11... 我是大路癡=  =\n', '2015-01-01');
INSERT INTO `suboard` VALUES (31, 51, 'Amy', '民宿那條路的轉角處啦', '2015-01-01');
INSERT INTO `suboard` VALUES (31, 52, 'Elaine', '謝恩人', '2015-01-01');
INSERT INTO `suboard` VALUES (12, 53, 'Chad', '我也需要~麻煩了~', '2015-01-01');
INSERT INTO `suboard` VALUES (33, 54, 'Amy', '真好~~~', '2015-01-01');
INSERT INTO `suboard` VALUES (12, 56, 'admin', 'received', '2015-01-01');
